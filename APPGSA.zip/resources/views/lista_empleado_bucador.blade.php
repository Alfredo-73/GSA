@foreach ($empleados as $emp)
{{$emp->legajo}}
@endforeach

