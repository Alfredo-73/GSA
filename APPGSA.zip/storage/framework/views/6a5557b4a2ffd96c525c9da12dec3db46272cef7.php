<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row container-fluid col-md-10 col-lg-10" id="contenido">

    <div class="container-fluid mx-auto text-center">
        <h1 class="mx-auto mb-5 mt-5" style="font-family:Verdana, Geneva, Tahoma, sans-serif">LISTADO DE EMPLEADOS</h1>
    </div>

    <div class="container-fluid">
        <nav class="navbar  navbar-dark indigo rounded mb-2">
            <p class="navbar-brand ml-2" href="#">Buscador:</p>

            <form class="form-inline md-form mr-auto mb-4 float-right" action="">
                <input name="buscarpornombre" id="nombre" class="form-control mr-sm-2 text-white" type="search" placeholder="Nombre del Empleado" aria-label="Search">
                <input name="buscarporapellido" id="apellido" class="form-control mr-sm-2 text-white" type="search" placeholder="Apellido del Empleado" aria-label="Search">
                <button class="btn blue-gradient btn-rounded btn-sm" type="submit"><i class="fas fa-search fa-2x mr-2" style="color:white"></i>Buscar</button>
                <a class="ml-2" href="<?php echo e(url('/empleado')); ?>" title="Refrescar" name="Refrescar" style="color:white; font-family:Verdana, Geneva, Tahoma, sans-serif"><i class="fas fa-sync-alt ml-1" style="color:white"></i>Refrescar</a>
            </form>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('agregar_empleado')): ?>
            <div>
                <a id="agregar" class="btn blue-gradient btn-rounded btn-sm" href="<?php echo e(url('/nuevo_empleado')); ?>" role="button" style="color:white"><i class="fas fa-2x fa-user-plus mr-2" style="color:white"></i>NUEVO</a>
            </div>
            <?php endif; ?>

            <a id="importar" class="btn btn-success ml-3" style="width:15rem;" href="<?php echo e(route ('empleado.excel')); ?>" role="button"><i class="far fa-file-excel mr-2"></i>EXPORTAR A EXCEL</a>
            <!--<a id="importar" class="btn-sm btn-danger ml-3" href="<?php echo e(route ('empleado.excel')); ?>" role="button">IMPORTAR EXCEL<i class="fa-2x far fa-file-excel ml-2"></i></a>-->

            <div class="badge  badge-pill badge-primary">
                <form action="<?php echo e(route('empleados.importar.excel')); ?>" method="post" enctype="multipart/form-data" class="ml-2" onclick="return alert('Seleccionar solo archivos con extencion .xlsx')">
                    <?php echo csrf_field(); ?>
                    <?php if(Session::has('message')): ?>
                    <p><?php echo e(Session::get('message')); ?></p>
                    <?php endif; ?>
                    <input type="file" name="archivo">
                    <button class="btn blue-gradient btn-sm text-truncate">IMP. EMPLEADOS</button>
                </form>
            </div>
        </nav>
    </div>

    <div class="row container-fluid">
        <?php echo e($empleados->appends($_GET)->links()); ?>

    </div>

    <style>
        /*CONFIGURO EL COLOR DE CANTIDAD DE SANCIONES*/
        .estado1 {
            color: red !important;
            font-weight: bold
        }

        .estado2 {
            color: blue !important;
            font-weight: bold
        }
    </style>
    <!--Table-->

    <div class="container-fluid">
        <div class="table-responsive-lg text-nowrap btn-table">
            <table class="table table-bordered table-hover">
                <thead class="thead-dark">
                    <thead class="text-center">
                        <tr height="65px" style="background-color:black; color:white">
                            <th class="text-center">LEGAJO</th>
                            <th class="text-center">NOMBRE</th>
                            <th class="text-center">APELLIDO</th>
                            <th class="text-center">CUIL</th>
                            <th class="text-center">FECHA INGRESO</th>
                            <th class="text-center">EMPRESA</th>
                            <th class="text-center">CAPATAZ</th>
                            <th class="text-center">CANTIDAD DE SANCIONES</th>
                            <th COLSPAN=4 class="text-center">ACCIONES DISPONIBLES</th>
                        </tr>
                    </thead>
                    <!--Table head-->

                    <!--Table body-->
                <tbody>
                    <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $cantidad_sanciones = 0; ?>
                    <?php $__currentLoopData = $sanciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sancion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if ($sancion['id_empleado'] == $empleado['id']) {
                        $cantidad_sanciones = $cantidad_sanciones + 1;
                    }
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center text-truncate"> <?php echo e($empleado->legajo); ?></td>
                        <td class="text-center text-truncate"><?php echo e($empleado->nombre); ?> </td>
                        <td class="text-center text-truncate"><?php echo e($empleado->apellido); ?> </td>
                        <td class="text-center text-truncate"> <?php echo e($empleado->cuil); ?></td>
                        <td class="text-center text-truncate" name="fecha"> <?php echo e($empleado->fecha_ingreso); ?></td>
                        <td class="text-center text-truncate"> <?php echo e($empleado->empresa->razon_social); ?></td>
                        <td class="text-center text-truncate"> <?php echo e($empleado->capataz->nombre); ?></td>
                        <?php if($cantidad_sanciones > '0'): ?>
                        <td class="estado1 text-center text-truncate"><?php echo e($cantidad_sanciones); ?></td>
                        <?php elseif($cantidad_sanciones == '0'): ?>
                        <td class="estado2 text-center text-truncate"><?php echo e($cantidad_sanciones); ?></td>
                        <?php endif; ?>
                        <td class="text-center" hidden="true"> <?php echo e($empleado->observaciones); ?></td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar_empleado')): ?>
                        <td class="text-center text-truncate">
                            <form method="POST" action="<?php echo e(url('/borrar_empleado/'.$empleado->id)); ?>">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <!--<a type="submit" onclick="return confirm('¿Desea eliminar el parte de empleado?')" id="borrar" class="btn peach-gradient btn-sm"><i class="fas fa-trash mr-2" style="color:white" role="button"></i>BORRAR
                                    </a>-->
                                <a type="submit" onclick="return confirm('¿Desea eliminar el parte de empleado?')" id="borrar" title="Borrar Registro" class="btn peach-gradient mb-1 btn-sm m-0 text-center text-truncate" style="color:white"><i class="fas fa-trash mr-0" style="color:white"></i> BORRAR</a>

                            </form>
                        </td>
                        <?php endif; ?>
                        <td class="text-center text-truncate">
                            <form method="PUT" action="/modal_empleado/<?php echo e($empleado->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('PUT')); ?>

                                <a type="button" class="btn blue-gradient btn-sm m-0" href="/modal_empleado/<?php echo e($empleado->id); ?>" data-toggle="modal" data-target="#modal_empleado<?php echo e($empleado->id); ?>" form method="POST" action="/modalempleado/<?php echo e($empleado->id); ?>" role="button" style="color:white"><i class="fas fa-eye mr-1" style="color:white"></i>VER</a>
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('PUT')); ?>

                                <?php echo $__env->make('modal_empleado', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </form>
                        </td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('agregar_sancion')): ?>
                        <td>
                            <a id="sancionar" class="btn blue-gradient btn-rounded btn-sm my-0 m-0" href="/nueva_sancion/<?php echo e($empleado->id); ?>" role="button" title="Ver Registro"><i class="fas fa-gavel mr-1" style="color:white"></i>SANCIONAR</a>
                        </td>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('leer_sancion')): ?>
                        <td>
                            <a id="sancionado" class="btn blue-gradient btn-rounded btn-sm my-0 m-0" href="/empleadoSancionado/<?php echo e($empleado->id); ?>" role="button"><i class="fas fa-list mr-1" style="color:white"></i>LISTADO SANCIONES</a>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <!--Table body-->
            </table>
            <div class="mt-3">
                <?php echo e($empleados->appends($_GET)->links()); ?>

            </div>
        </div>
    </div>
</div>
<!--Table-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alfredosarria/GSA/resources/views/empleado.blade.php ENDPATH**/ ?>