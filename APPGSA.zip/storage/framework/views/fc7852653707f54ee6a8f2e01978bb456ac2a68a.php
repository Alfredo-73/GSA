<div class="modal fade" id="modalcosecha<?php echo e($cosecha->id); ?>" tabindex="3" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title w-100 font-weight-bold text-center" style="color:darkblue; font-family:Verdana, Geneva, Tahoma, sans-serif">PARTE DIARIO DE COSECHA</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="margin-left:3rem">
                <div class="modal-body" style="margin-left:0rem">
                    <div class="row">
                        <!--<input hidden="true" type="text" id="orangeForm-name" class="form-control" value="<?php if(!empty($cosecha->id_cliente)): ?> <?php echo e($cosecha->id_cliente); ?><?php endif; ?>" name="id_cliente">
                        <input hidden="true" type="text" id="orangeForm-name" class="form-control" value="<?php if(!empty($cosecha->id_capataz)): ?> <?php echo e($cosecha->id_capataz); ?><?php endif; ?>" name="id_capataz">-->
                        <div class="md-form mb-1" style="width:30%">
                            <i class="far fa-calendar-alt prefix" style="margin-left:-4rem; color:darkblue"></i>
                            <input id="fecha" type="date" class="form-control <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> text-center" name="fecha" value="<?php echo e($cosecha->fecha); ?>" required autocomplete="fecha" autofocus>
                            <label style="color:darkblue">FECHA</label>
                            <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="md-form mt-3 mx-auto" style="width:30%">
                            <i class="fas fa-id-card-alt prefix" style="margin-left:-4rem; color:darkblue"></i>
                            <label style="color:darkblue">CLIENTE</label>
                            <br>
                            <br>
                            <select class="selectpicker show-menu-arrow" name="id_cliente">
                                <option value="<?php echo e($cosecha->id_cliente); ?>"><?php echo e($cosecha->cliente->nombre); ?></option>
                                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="md-form mt-3" style="width:50%">
                            <i class="fas fa-user prefix" style="margin-left:-7rem; color:darkblue"></i>
                            <label style="color:darkblue">CAPATAZ</label>
                            <br>
                            <br>
                            <select class="selectpicker show-menu-arrow" name="id_capataz">
                                <option value="<?php echo e($cosecha->id_capataz); ?>"><?php echo e($cosecha->capataz->nombre); ?></option>
                                <?php $__currentLoopData = $capataz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($capat->id); ?>"><?php echo e($capat->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="md-form mb-1" style="width:50%">
                            <i class="fas fa-users prefix" style="margin-left:-7rem; color:darkblue"></i>
                            <input style="width:2rem" type="text" class="form-control text-center" value="<?php if(!empty($cosecha->jornales)): ?> <?php echo e($cosecha->jornales); ?><?php endif; ?>" name="jornales">
                            <label style="color:darkblue" data-error="wrong" data-success="right" for="orangeForm-pass"><?php echo e(__('JORNALES')); ?></label>
                        </div>

                        <div class="md-form mb-1" style="width:50%">
                            <i class="fas fa-users prefix" style="margin-left:-7rem; color:darkblue"></i>
                            <input style="width:2rem" type="text" class="form-control text-center" value="<?php if(!empty($cosecha->cosecheros)): ?> <?php echo e($cosecha->cosecheros); ?><?php endif; ?>" name="cosecheros">
                            <label style="color:darkblue" data-error="wrong" data-success="right" for="orangeForm-pass">COSECHEROS</label>
                        </div>
                        <div class="md-form mb-1 w-50">
                            <i class="fas fa-truck-loading prefix" style="margin-left:-7rem; color:darkblue"></i>
                            <input style="width:3rem" type="text" class="form-control text-center" value="<?php if(!empty($cosecha->bines)): ?> <?php echo e($cosecha->bines); ?><?php endif; ?>" name="bines">
                            <label style="color:darkblue" data-error="wrong" data-success="right" for="orangeForm-pass">BINES</label>
                        </div>

                        <div class="md-form mb-1 w-50">
                            <i class="fas fa-lemon prefix" style="margin-left:-7rem; color:darkblue"></i>
                            <input style="width:4rem" type="text" class="form-control text-center" value="<?php if(!empty($cosecha->maletas)): ?> <?php echo e($cosecha->maletas); ?><?php endif; ?>" name="maletas">
                            <label style="color:darkblue" data-error="wrong" data-success="right" for="orangeForm-pass">MALETAS</label>
                        </div>
                        <div class="md-form mb-1 w-50">

                            <i class="fas fa-weight-hanging prefix" style="margin-left:-7rem; color:darkblue"></i>
                            <input style="width:4rem" type="text" class="form-control text-center" value="<?php if(!empty($cosecha->toneladas)): ?> <?php echo e($cosecha->toneladas); ?><?php endif; ?>" name="toneladas">
                            <label style="color:darkblue" data-error="wrong" data-success="right" for="orangeForm-pass">TONELADAS</label>
                        </div>
                        <div class="md-form mb-1 w-50">
                            <i class="fas fa-weight prefix" style="margin-left:-7rem; color:darkblue"></i>
                            <input style="width:4rem" type="text" class="form-control text-center" value="<?php if(!empty($cosecha->prom_kg_bin)): ?> <?php echo e($cosecha->prom_kg_bin); ?><?php endif; ?>" name="prom_kg_bin" pattern="{0000.00}">
                            <label style="color:darkblue" data-error="wrong" data-success="right" for="orangeForm-pass">PROMEDIO KG/BIN</label>
                        </div>
                        <div class="md-form mb-1 w-50">
                            <i class="fas fa-user prefix" style="margin-left:-7rem; color:darkblue"></i>
                            <input style="width:6rem" type="text" class="form-control text-center" value="<?php if(!empty($cosecha->supervisor)): ?> <?php echo e($cosecha->supervisor); ?><?php endif; ?>" name="supervisor">
                            <label style="color:darkblue" data-error="wrong" data-success="right" for="orangeForm-pass" s>SUPERVISOR</label>
                        </div>
                        <div class="md-form mb-1 w-50">
                            <i class="fas fa-bus prefix" style="margin-left:-7rem; color:darkblue"></i>
                            <input style="width:10rem" type="text" class="form-control text-center" value="<?php if(!empty($cosecha->transportista)): ?> <?php echo e($cosecha->transportista); ?><?php endif; ?>" name="transportista">
                            <label style="color:darkblue" data-error="wrong" data-success="right" for="orangeForm-pass" s>TRANSPORTISTA</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer" style="width:100%">
                <div class="mx-auto">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update_cosecha')): ?>
                    <button type="submit" class="btn btn-primary" action="<?php echo e(url('/modalcosecha/'.$cosecha->id)); ?>"><i class="fas fa-2x fa-save mr-2" style="color:white"></i>
                        <?php echo e(__('Grabar')); ?>

                    </button>
                    <?php endif; ?>
                    <a class="btn btn-deep-orange" href="<?php echo e(action('cosechaController@vercosechaPDF', $cosecha->id)); ?>"><i class="fas fa-2x fa-print mr-2" style="color:white"></i>Imprimir</a>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar_cosecha')): ?>
                    <form method="POST" action="<?php echo e(url('/borrar_cosecha/'.$cosecha->id)); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                        <button hidden="true" type="submit" onclick="return confirm('¿Desea eliminar el parte de cosecha?')" id="borrar" class="btn btn-danger btn-rounded mb-1 btn-sm m-0 text-center"> BORRAR
                        </button>
                    </form>
                    <?php endif; ?>
                </div>

            </div>
        </div><?php /**PATH /Users/alfredosarria/GSA/resources/views/modalcosecha.blade.php ENDPATH**/ ?>