<?php $__env->startSection('content'); ?>
<div class=" container-fluid">

    <div class="view overlay col-10" style="margin-top:0rem; height:50rem">
        <img src="<?php echo e(asset('img/gsagricolas.jpg')); ?>" class="img-fluid mx-auto" alt="Sample image with waves effect.">
       <!--<img src="<?php echo e(asset('img/logotipo-y-logo.jpg')); ?>" class="img-fluid mx-auto" alt="Sample image with waves effect.">-->
        <a>
            <!--<div class="mask waves-effect rgba-white-slight"></div>-->
        </a>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alfredosarria/GSA/resources/views/inicio.blade.php ENDPATH**/ ?>