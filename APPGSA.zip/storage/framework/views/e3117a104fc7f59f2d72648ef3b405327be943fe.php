<?php $__env->startSection('content'); ?>

<div class="row container-fluid col-10 mx-auto" id="contenido">
  <h1 class="mx-auto mt-5 mb-3" style="font-family:Verdana, Geneva, Tahoma, sans-serif">MANTENIMIENTO DE USUARIOS</h1>

  <div class="pull-right col-lg-12 col-md-12 col-sm-12">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>
    <a class="btn primary-color-dark mb-5 rounded" href="<?php echo e(route('users.create')); ?>" style="margin-left:60%; color:white"><i class="fas fa-2x fa-user-plus mr-2" style="color:white"></i>NUEVO</a>
    <?php endif; ?>
  </div>


  <?php if($message = Session::get('success')): ?>
  <div class="alert alert-success">
    <p><?php echo e($message); ?></p>
  </div>
  <?php endif; ?>

  <div class="container mx-auto">
    <div class="table-responsive text-nowrap btn-table">
      <table class="table table-bordered table-hover">
        <thead class="thead-dark">
          <thead class="text-center">
            <tr height="65px" style="background-color:black; color:white">
              <th class="text-center">#</th>
              <th class="text-center">NOMBRE USUARIO</th>
              <th class="text-center">CORREO ELECTRONICO</th>
              <th class="text-center">ROL ASIGNADO</th>
              <th class="text-center" width="250px">ACCIONES</th>
            </tr>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e(++$i); ?></td>
              <td class="text-uppercase"><?php echo e($user->name); ?></td>
              <td><?php echo e($user->email); ?></td>
              <td class="text-center">
                <?php if(!empty($user->getRoleNames())): ?>
                <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="badge badge-success text-uppercase" style="font-size:15px"><?php echo e($v); ?></label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </td>
              <td>
                <!--<a class="btn-sm btn-info" href="<?php echo e(route('users.show',$user->id)); ?>">VER</a>-->
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-edit')): ?>
                <button class="btn-sm btn-primary" onclick="location.href='<?php echo e(route('users.edit',$user->id)); ?>'">EDITAR</button>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-delete')): ?>
                <?php echo Form::open(['method' => 'DELETE','route' => ['users.destroy', $user->id],'style'=>'display:inline']); ?>

                <?php echo Form::submit('BORRAR', ['class' => 'btn-sm btn-danger']); ?>

                <?php echo Form::close(); ?>

                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </thead>
        </thead>
      </table>
    </div>
  </div>
</div>

<?php echo $data->render(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alfredosarria/GSA/resources/views/users/index.blade.php ENDPATH**/ ?>