<?php $__env->startSection('content'); ?>
<div class="row container-fluid col-10 mt-5" id="contenido">
    <div class="col-8 mx-auto mt-5">
        <div class="card">
            <div class="card-header text-white text-center" style="background-color:darkblue; font-size:25px">ALTA DE NUEVO PERMISO</div>
            <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> Tenemos un problema con su entrada.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <?php echo Form::open(array('route' => 'permisos.store','method'=>'POST')); ?>

            <div class="input-group col-10 mt-4 d-flex justify-content-center align-items-center container">
                <div class="input-group-prepend">
                    <span class="input-group-text"><strong>NOMBRE DEL PERMISO</strong></span>
                </div>
                <input type="text" name="name" aria-label="name" class="form-control">
            </div>
            <div class="row justify-content-center mt-3">
                <div class="form-group col-md-6 col-form-label text-center">
                    <button type="submit" class="btn btn-success">GRABAR</button>
                    <a class="btn btn-primary" href="<?php echo e(route('permisos.index')); ?>"> REGRESAR</a>
                </div>
            </div>
        </div>


    </div>
</div>
<?php echo Form::close(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alfredosarria/GSA/resources/views/permisos/create.blade.php ENDPATH**/ ?>