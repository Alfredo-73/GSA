 

<div class="modal fade" id="modal_sancion<?php echo e($sancion->id); ?>" tabindex="3" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title w-100 font-weight-bold text-center" style="color:darkblue">EMPLEADO:  <?php if(!empty($sancion->nombre)): ?><?php echo e($sancion->nombre); ?>   <?php echo e($sancion->apellido); ?><?php endif; ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                </button>
            </div>
                  

                                
            <div class="modal-body " style="margin-left:3rem">
                <div class="row">
                     
                    <div class="md-form mb-1" style="width:100%">
                         <input  style="width:10rem" type="text" id="orangeForm-pass" class="form-control" value="<?php if(!empty($sancion->empresa->razon_social)): ?> <?php echo e($sancion->empresa->razon_social); ?> <?php endif; ?>">
                        <label data-error="wrong" data-success="right" for="orangeForm-pass" style="color:blue">EMPRESA</label>   
                        </div>


                        <div class="md-form mb-1" style="width:100%">
                        <i class="fas fa-id-card-alt prefix" style="color:darkblue"></i>
                        <input  style="width:7rem" type="text" id="orangeForm-pass" class="form-control" value="<?php if(!empty($sancion->capataz->nombre)): ?> <?php echo e($sancion->capataz->nombre); ?> <?php endif; ?>">
                        <label data-error="wrong" data-success="right" for="orangeForm-pass" style="color:blue">CAPATAZ</label>
                        </div>
                        <div class="md-form mb-1" style="width:50%">
                        <i class="fas fa-book prefix"  style="color:darkblue"></i>
                        <input  style="width:5rem" type="text" id="orangeForm-pass" class="form-control" value="<?php if(!empty($sancion->legajo)): ?> <?php echo e($sancion->legajo); ?> <?php endif; ?>">
                        <label data-error="wrong" data-success="right" for="orangeForm-pass" style="color:blue">LEGAJO EMPLEADO </label>
                        </div>
                        
                        <div class="md-form mb-1" style="width:50%">
                        <i class="fas fa-dollar-sign prefix" style="color:darkblue"></i>
                        <input  style="width:5rem" type="text" id="orangeForm-pass" class="form-control" value="<?php if(!empty($sancion)): ?><?php echo e($sancion->dias); ?> <?php endif; ?>">
                        <label data-error="wrong" data-success="right" for="orangeForm-pass" style="color:blue">DIAS  </label>
                        </div>

                        <div class="md-form mb-1" style="width:50%">
                        <i class="fas fa-dollar-sign prefix" style="color:darkblue"></i>
                        <input  style="width:7rem" type="text" id="orangeForm-pass" class="form-control" value="<?php if(!empty($sancion)): ?> <?php echo e($sancion->fecha); ?> <?php endif; ?>">
                        <label data-error="wrong" data-success="right" for="orangeForm-pass" style="color:blue">FECHA SANCION  </label>
                        </div>

                        <div class="md-form mb-1" style="width:50%">
                        <i class="fas fa-dollar-sign prefixapp prefix" style="color:darkblue"></i>
                        <input  style="width:7rem" type="text" id="orangeForm-pass" class="form-control" value="<?php if(!empty($sancion)): ?><?php echo e($sancion->reincorporacion); ?> <?php endif; ?>">
                        <label data-error="wrong" data-success="right" for="orangeForm-pass" style="color:blue">REINCORPORACION   </label>
                        </div>

                        <div class="md-form mb-1" style="width:50%">
                        <i class="fas fa-dollar-sign prefixapp prefix" style="color:darkblue"></i>
                        <input  style="width:5rem" type="text" id="orangeForm-pass" class="form-control" value="<?php if(!empty($sancion)): ?> <?php echo e($sancion->motivo); ?> <?php endif; ?>">
                        <label data-error="wrong" data-success="right" for="orangeForm-pass" style="color:blue">MOTIVO </label>
                        </div>
                        <div class="md-form mb-1" style="width:50%">
                        <i class="fas fa-dollar-sign prefixapp prefix" style="color:darkblue"></i>
                        <input  style="width:5rem" type="text" id="orangeForm-pass" class="form-control" value="<?php if(!empty($sancion)): ?><?php echo e($sancion->observacion); ?> <?php endif; ?>">
                        <label data-error="wrong" data-success="right" for="orangeForm-pass" style="color:blue">OBSERVACION   </label>
                        </div>
                        
                </div>

            </div>
            
                <div class="modal-footer" style="width:100%">
                    <div class="mx-auto">
                    
                        <a id="modificar" class="btn btn-primary " href="/../modif_sancion/<?php echo e($sancion->id); ?>"  ><i class="far fa-edit mr-2"></i>Modificar </a>

                      
                        <a class="btn btn-deep-orange" href="/../PDFSancion/<?php echo e($sancion->id); ?>"><i class="fas fa-print mr-2 " style="color:white"></i>Imprimir</a>

                    </div>
                </div>
        </div>                
            
        
    </div>
                          
</div>



    
<?php /**PATH /Users/alfredosarria/GSA/resources/views/modal_sancion.blade.php ENDPATH**/ ?>