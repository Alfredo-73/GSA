<?php $__env->startSection('content'); ?>
<div class="row container-fluid col-6 mx-auto" id="contenido">
    <div class="container-fluid mx-auto text-center">
        <h1 class="mx-auto mb-5 mt-5" style="font-family:Verdana, Geneva, Tahoma, sans-serif">LISTADO DE QUINCENAS</h1>
        <a id="agregar" class="btn primary-color-dark mb-5 rounded" href="<?php echo e(url('/nueva_quincena')); ?>" role="button" style="margin-left:60%;color:white"><i class="fas fa-2x fa-plus mr-2" style="color:white"></i>NUEVA </a>
    </div>
    <!--TABLE-->
    <div class="container-fluid mx-auto">
        <div class="table-responsive text-nowrap btn-table">
            <table class="table table-bordered table-hover">
                <thead class="thead-dark">
                    <thead class="text-center">
                        <tr height="65px" style="background-color:black; color:white">
                            <th class="text-center">DESCRIPCION PERIODO </th>
                            <th COLSPAN=2 class="text-center">ACCIONES DISPONIBLES</th>
                        </tr>
                    </thead>
                    <!--Table body-->
                <tbody>
                    <?php $__currentLoopData = $quincenas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quincena): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"> <?php echo e($quincena->nombre); ?></td>
                        <td>
                            <form method="POST" action="<?php echo e(url('/borrar_quincena/'.$quincena->id)); ?>">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <button type="submit" onclick="return confirm('¿Desea eliminar la quincena?')" id="borrar" class="btn btn-danger btn-rounded mb-4"><i class="fas fa-trash mr-2" style="color:white" role="button"></i> BORRAR
                                </button>

                                <!-- <button class="btn btn-danger" type="submit" id="borrar">Borrar</button>-->
                            </form>

                        </td>
                        <!--BOTON MODIFICAR NO FUNCIONA LA VISTA MODIFPRODUCTO, SI TOMA EL ID DEL PREODUCTO-------->
                        <td class="text-center">
                            <a id="modificar" class="btn btn-primary btn-rounded mb-4" href="/modif_quincena/<?php echo e($quincena->id); ?>" role="button">Modificar </a>

                        </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>


                </tbody>
                <!--Table body-->
            </table>
        </div>

        <div class="modal fade" id="modalRegisterForm" tabindex="-2" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">


                    <div class="modal-header text-center">
                        <h4 class="modal-title w-100 font-weight-bold">quincena <?php if(!empty($quincena)): ?><?php echo e($quincena->id); ?> <?php endif; ?></h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body mx-3">
                        <div class="md-form mb-5">
                            <i class="fas fa-book prefix grey-text"></i>
                            <input type="text" id="orangeForm-name" class="form-control validate">
                            <label data-error="wrong" data-success="right" for="orangeForm-name">Nombre <?php if(!empty($quincena)): ?><?php echo e($quincena->nombre); ?> <?php endif; ?></label>
                        </div>


                    </div>
                    <div class="modal-footer d-flex justify-content-center">
                        <button class="btn btn-deep-orange">Imprimir</button>
                    </div>

                </div>
            </div>
        </div>

        <!--Table-->
    </div>

</div>

<!--Section: Content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alfredosarria/GSA/resources/views/abm_quincena.blade.php ENDPATH**/ ?>