<?php $__env->startSection('content'); ?>
<div class="row container-fluid col-10 mt-5" id="contenido">

        <div class="col-8 mx-auto mt-5">
            <div class="card">
                <div class="card-header text-white text-center" style="background-color:darkblue; font-size:25px">ALTA DE NUEVO ROL</div>


                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <strong>Whoops!</strong> Tenemos un problema con su entrada.<br><br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>


                <?php echo Form::open(array('route' => 'roles.store','method'=>'POST')); ?>

                <!--<div class="row justify-content-center">
                    <div class="form-group col-md-6 col-form-label text-md-left">
                        <strong>NOMBRE DEL ROL:</strong>
                        <?php echo Form::text('name', null, array('placeholder' => 'Nombre','class' => 'form-control')); ?>

                    </div>
                </div>-->

                <div class="input-group col-10 mt-4 mb-4 d-flex justify-content-center align-items-center container">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><strong>NOMBRE DEL NUEVO ROL</strong></span>
                    </div>
                    <input type="text" name="name" aria-label="name" class="form-control">
                </div>

                <div class="card ml-3" style="width:95%">
                    <div class="row justify-content-center mb-3" style="font-size:18px">
                        <strong>PERMISOS DISPONIBLES PARA EL NUEVO ROL</strong>
                    </div>

                    <div class="row justify">
                        <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-3 mr-1 justify-content-center align-items-center container">
                            <label><?php echo e(Form::checkbox('permission[]', $value->id, false, array('class' => 'name'))); ?>

                                <?php echo e($value->name); ?></label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="row justify-content-center mt-3">
                    <div class="form-group col-md-6 col-form-label text-center">
                        <button type="submit" class="btn btn-success">GRABAR</button>
                        <a class="btn btn-primary" href="<?php echo e(route('roles.index')); ?>"> REGRESAR</a>
                    </div>
                </div>
            </div>
            <?php echo Form::close(); ?>


        </div>
    </div>
            <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alfredosarria/GSA/resources/views/roles/create.blade.php ENDPATH**/ ?>