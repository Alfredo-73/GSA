<!DOCTYPE html>

<html>

<head>

<title>Sancion</title>

</head>

<body>
<h4>Legajo: <?php echo e($sancion->legajo); ?></h4>
<h4>Cuadrilla:</h4>
<h2>NOTIFICACION DE SUSPENSION </h2>

<p>Atento a su <?php echo e($sancion->motivo); ?> en su puesto de trabajo, registrada el día <?php echo e($sancion->fecha); ?>, y resultando 
su conducta violatoria de los deberes impuestos por los art. 84, 85 y 86 de la L.C.T., la empresa ha decidido 
aplicarle una sanción disciplinaria de <?php echo e($sancion->dias); ?> días de suspensión sin goce de haberes.

Consecuentemente, queda Ud. suspendido desde el día <?php echo e($sancion->fecha); ?>  hasta el <?php echo e($sancion->reincorporacion); ?> inclusive,
debiendo retomar tareas el día <?php echo e($sancion->reincorporacion); ?> en forma habitual.
En fecha  <?php echo e($sancion->fecha); ?> se notifica al empleado,

APELLIDO Y NOMBRE: <?php echo e($sancion->apellido); ?> <?php echo e($sancion->nombre); ?>


TIPO Y Nº de DNI: <?php echo e($sancion->dni); ?>





      ……………………………………                                                                              ……………………………………
           Firma                                                                                    Aclaración
</p>
<p>________________________________________________________________________________</p>
<p>Atento a su <?php echo e($sancion->motivo); ?> en su puesto de trabajo, registrada el día <?php echo e($sancion->fecha); ?>, y resultando 
su conducta violatoria de los deberes impuestos por los art. 84, 85 y 86 de la L.C.T., la empresa ha decidido 
aplicarle una sanción disciplinaria de <?php echo e($sancion->dias); ?> días de suspensión sin goce de haberes.

Consecuentemente, queda Ud. suspendido desde el día <?php echo e($sancion->fecha); ?>  hasta el <?php echo e($sancion->reincorporacion); ?> inclusive,
debiendo retomar tareas el día <?php echo e($sancion->reincorporacion); ?> en forma habitual.
En fecha  <?php echo e($sancion->fecha); ?> se notifica al empleado,

APELLIDO Y NOMBRE: <?php echo e($sancion->apellido); ?> <?php echo e($sancion->nombre); ?>


TIPO Y Nº de DNI: <?php echo e($sancion->dni); ?>





      ……………………………………                                                                              ……………………………………
           Firma                                                                                    Aclaración
</p>
</body>

</html>


<?php /**PATH /Users/alfredosarria/GSA/resources/views/PDFSancion.blade.php ENDPATH**/ ?>