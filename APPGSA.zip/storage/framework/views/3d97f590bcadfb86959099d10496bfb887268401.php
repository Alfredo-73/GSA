<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <section>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header text-white text-center" style="background-color:darkblue" ><?php echo e(__('MODIFICACION SANCION DISCIPLINARIA')); ?></div>
                   <div class="mt-3">
                        <ul style='color:red' class="text-center">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li style='list-style:none'>
                                <?php echo e($error); ?>

                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
 
                <div class="card-body">
                    <form method="POST" action="/modif_empleado/<?php echo e($empleado->id); ?>" >
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PUT')); ?>

                        
                    <div class="form-group row">   

                     <label for="legajo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('LEGAJO')); ?></label>
                   
                        <div class="col-md-6">
                                <input id="legajo" type="text" class="form-control" name="legajo" value="<?php echo e($empleado->legajo); ?>">
                     
                        </div>
                    </div> 

                        <div class="form-group row">
                            <label for="nombre" class="col-md-4 col-form-label text-md-right"><?php echo e(__('NOMBRE')); ?></label>

                            <div class="col-md-6">
                                <input id="nombre" type="text" class="form-control" name="nombre" value="<?php echo e($empleado->nombre); ?>">

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="apellido" class="col-md-4 col-form-label text-md-right"><?php echo e(__('APELLIDO')); ?></label>

                            <div class="col-md-6">
                                <input id="apellido" type="text" class="form-control" name="apellido"  value="<?php echo e($empleado->apellido); ?>" >

                            </div>
                        </div>

                        <div class="form-group row">   
     
                            <label for="dni" class="col-md-4 col-form-label text-md-right"><?php echo e(__('DNI')); ?></label>
                                <div class="form-group row">
                                    
                                    <div class="col-md-6">
                                        <input id="dni" type="text" class="form-control" name="dni" value="<?php echo e($empleado->dni); ?>" >
                                       
                                    </div>
                                </div>
                             
                        </div>        
                        <div class="form-group row">
                            <label for="cuil" class="col-md-4 col-form-label text-md-right"><?php echo e(__('CUIL')); ?></label>
                            
                            <div class="col-md-6">
                                <input id="cuil" type="text" class="form-control" name="cuil" value="<?php echo e($empleado->cuil); ?>" >

                                
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="fecha_ingreso" class="col-md-4 col-form-label text-md-right"><?php echo e(__('FECHA INGRESO')); ?></label>

                            <div class="col-md-6">
                                <input id="fecha_ingreso" type="date" class="form-control " name="fecha_ingreso" value="<?php echo e($empleado->fecha_ingreso); ?>"  >

                               
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="fecha_egreso" class="col-md-4 col-form-label text-md-right"><?php echo e(__('FECHA EGRESO')); ?></label>

                            <div class="col-md-6">
                                <input id="fecha_egreso" type="date" class="form-control " name="fecha_egreso" value="<?php echo e($empleado->fecha_egreso); ?>" >

                               
                            </div>
                        </div>


       
                        <div class="form-group row">   
    
                            <label for="id_empresa" class="col-md-4 col-form-label text-md-right"><?php echo e(__('EMPRESA')); ?></label>
                        
                                <select class="selectpicker show-menu-arrow" name="id_empresa" data-style="btn-success" data-width="auto">
                                <option value="<?php echo e($empleado->id_empresa); ?>" selected></option>
                                <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             
                                <option value="<?php echo e($empresa->id); ?>"><?php echo e($empresa->razon_social); ?></option>
                               
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                            </select>                              
                            
                        </div>                       
                        <div class="form-group row">   
    
                            <label for="id_capataz" class="col-md-4 col-form-label text-md-right"><?php echo e(__('CAPATAZ')); ?></label>
                        
                                <select class="selectpicker show-menu-arrow" name="id_capataz" data-style="btn-success" data-width="auto">
                                <option value="<?php echo e($empleado->id_capataz); ?>" selected></option>
                                <?php $__currentLoopData = $capataz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             
                                <option value="<?php echo e($capat->id); ?>"><?php echo e($capat->nombre); ?></option>
                               
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                            </select>                              
                            
                        </div>  
                       
                       
                             
                        <div class="form-group row shadow-textarea green-border-focus">

                         <!--   <div class="form-group shadow-textarea"> -->
                            <label for="observaciones"><?php echo e(__('OBSERVACION')); ?></label>
                             <textarea class="form-control z-depth-1" id="observaciones" rows="3" name="observaciones"><?php echo e($empleado->observaciones); ?></textarea>
                            </div>

                        </div>
                        

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-2x fa-save mr-2" style="color:white"></i>
                                    <?php echo e(__('Grabar')); ?>

                                </button>
                                 <a class="fas fa-undo" role="button" href=  <?php echo e(url('/empleado')); ?> style='margin-left:5rem' style="cursor:pointer",name="Regresar" >  Regresar</a>
           
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </section>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alfredosarria/GSA/resources/views/modif_empleado.blade.php ENDPATH**/ ?>