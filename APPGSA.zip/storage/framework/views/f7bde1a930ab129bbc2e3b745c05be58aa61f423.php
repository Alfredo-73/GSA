 

<div class="modal fade" id="modal_empleado<?php echo e($empleado->id); ?>" tabindex="3" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title w-100 font-weight-bold text-center" style="color:darkblue">EMPLEADO:  <?php if(!empty($empleado->nombre)): ?><?php echo e($empleado->nombre); ?> .  <?php echo e($empleado->apellido); ?><?php endif; ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                </button>
            </div>
                  

                                
            <div class="modal-body " style="margin-left:3rem">
                <div class="row">
                     
                        <div class="md-form mb-1" style="width:50%">
                        <i class="fas fa-id-card-alt prefix" style="color:darkblue"></i>
                        <input  style="width:7rem" type="text"  class="form-control" value="<?php if(!empty($empleado->empresa)): ?> <?php echo e($empleado->empresa->razon_social); ?> <?php endif; ?>">
                        <label data-error="wrong" data-success="right" for="orangeForm-pass" style="color:blue">EMPRESA</label>
                        </div>
                        <div class="md-form mb-1" style="width:50%">
                        <i class="fas fa-book prefix"  style="color:darkblue"></i>
                        <input  style="width:5rem" type="text" class="form-control" value="<?php if(!empty($empleado->legajo)): ?> <?php echo e($empleado->legajo); ?> <?php endif; ?>">
                        <label data-error="wrong" data-success="right" for="orangeForm-pass" style="color:blue">LEGAJO </label>
                        </div>
                        <div class="md-form mb-1" style="width:50%">
                        <i class="fas fa-dollar-sign prefix " style="color:darkblue"></i>
                        <input  style="width:5rem" type="text" class="form-control" value="<?php if(!empty($empleado)): ?> <?php echo e($empleado->nombre); ?> <?php endif; ?>">
                        <label data-error="wrong" data-success="right" for="orangeForm-pass" style="color:blue">NOMBRE </label>
                        </div>

                        <div class="md-form mb-1" style="width:50%">
                        <i class="fas fa-dollar-sign prefix" style="color:darkblue"></i>
                        <input  style="width:5rem" type="text" class="form-control" value="<?php if(!empty($empleado)): ?><?php echo e($empleado->apellido); ?> <?php endif; ?>">
                        <label data-error="wrong" data-success="right" for="orangeForm-pass" style="color:blue">APELLIDO  </label>
                        </div>

                        <div class="md-form mb-1" style="width:50%">
                        <i class="fas fa-dollar-sign prefix" style="color:darkblue"></i>
                        <input  style="width:5rem" type="text" class="form-control" value="<?php if(!empty($empleado)): ?> <?php echo e($empleado->dni); ?> <?php endif; ?>">
                        <label data-error="wrong" data-success="right" for="orangeForm-pass" style="color:blue">DNI  </label>
                        </div>

                        <div class="md-form mb-1" style="width:50%">
                        <i class="fas fa-dollar-sign prefixapp prefix" style="color:darkblue"></i>
                        <input  style="width:5rem" type="text" class="form-control" value="<?php if(!empty($empleado)): ?><?php echo e($empleado->cuil); ?> <?php endif; ?>">
                        <label data-error="wrong" data-success="right" for="orangeForm-pass" style="color:blue">CUIL   </label>
                        </div>

                        <div class="md-form mb-1" style="width:50%">
                        <i class="fas fa-dollar-sign prefixapp prefix" style="color:darkblue"></i>
                        <input  style="width:5rem" type="text" class="form-control" value="<?php if(!empty($empleado)): ?> <?php echo e($empleado->fecha_ingreso); ?> <?php endif; ?>">
                        <label data-error="wrong" data-success="right" for="orangeForm-pass" style="color:blue">FECHA INGRESO </label>
                        </div>
                        <div class="md-form mb-1" style="width:50%">
                        <i class="fas fa-dollar-sign prefixapp prefix" style="color:darkblue"></i>
                        <input  style="width:5rem" type="text" class="form-control" value="<?php if(!empty($empleado)): ?><?php echo e($empleado->fecha_egreso); ?> <?php endif; ?>">
                        <label data-error="wrong" data-success="right" for="orangeForm-pass" style="color:blue">FECHA EGRESO   </label>
                        </div>
                        <div class="md-form mb-1" style="width:50%">
                        <i class="fas fa-dollar-sign prefixapp prefix" style="color:darkblue"></i>
                        <input  style="width:5rem" type="text" class="form-control" value="<?php if(!empty($empleado->capataz)): ?>  <?php echo e($empleado->capataz->nombre); ?> <?php endif; ?>">
                        <label data-error="wrong" data-success="right" for="orangeForm-pass" style="color:blue">CAPATAZ </label>
                        </div>
                        <div class="md-form mb-1" style="width:50%">
                        <i class="fas fa-dollar-sign prefixapp prefix" style="color:darkblue"></i>
                        <input  style="width:5rem" type="text" class="form-control" value="<?php if(!empty($empleado->sanciones)): ?> <?php echo e($empleado->sanciones->fecha); ?> <?php endif; ?>">
                        <label data-error="wrong" data-success="right" for="orangeForm-pass" style="color:blue">ULTIMA SANCION </label>
                        </div>
                </div>

            </div>
            
                <div class="modal-footer" style="width:100%">
                    <div class="mx-auto">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update_empleado')): ?>
                        <a id="modificar" class="btn btn-primary " href="/../modif_empleado/<?php echo e($empleado->id); ?>"  ><i class="far fa-edit mr-2"></i>Modificar </a>
                    <?php endif; ?>
                      
                       <!-- <a class="btn btn-deep-orange" href="/../PDFEmpleado/<?php echo e($empleado->id); ?> "><i class="fas fa-print mr-2 " style="color:white"></i>Imprimir</a>-->

                    </div>
                </div>
        </div>                
            
        
    </div>
                          
</div>


<?php /**PATH /Users/alfredosarria/GSA/resources/views/modal_empleado.blade.php ENDPATH**/ ?>