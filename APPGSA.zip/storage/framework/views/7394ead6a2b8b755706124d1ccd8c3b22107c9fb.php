<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <section>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header text-white text-center" style="background-color:darkblue" ><?php echo e(__('MODIFICACION SANCION DISCIPLINARIA')); ?></div>
                   <div class="mt-3">
                        <ul style='color:red' class="text-center">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li style='list-style:none'>
                                <?php echo e($error); ?>

                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
 
                <div class="card-body">
                    <form method="POST" action="/modif_sancion/<?php echo e($sancion->id); ?>" >
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PUT')); ?>

                     
                        <div class="form-group row">
                            <label for="legajo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('LEGAJO')); ?></label>

                            <div class="col-md-6">

                                <input id="orangeForm-pass" type="text" class="form-control"  value="<?php if(!empty($empleado)): ?><?php echo e($empleado->legajo); ?> <?php endif; ?>" >

                                
                            </div>

                           
                        </div> 

                        <div class="form-group row">
                            <label for="nombre" class="col-md-4 col-form-label text-md-right"><?php echo e(__('NOMBRE')); ?></label>

                            <div class="col-md-6">
                                <input id="nombre" type="text" class="form-control"  value="<?php if(!empty($empleado)): ?><?php echo e($empleado->nombre); ?> <?php endif; ?>" >

                               
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="apellido" class="col-md-4 col-form-label text-md-right"><?php echo e(__('APELLIDO')); ?></label>

                            <div class="col-md-6">
                                <input id="apellido" type="text" class="form-control "   value="<?php if(!empty($empleado)): ?><?php echo e($empleado->apellido); ?> <?php endif; ?>" >

                                
                            </div>
                        </div>

                        
                        <div class="form-group row">
                            <label for="dni" class="col-md-4 col-form-label text-md-right"><?php echo e(__('DNI')); ?></label>
                            
                            <div class="col-md-6">
                                <input id="dni" type="text" class="form-control" name="dni" value="<?php if(!empty($empleado)): ?><?php echo e($empleado->dni); ?> <?php endif; ?>" >

                               
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="dias" class="col-md-4 col-form-label text-md-right"><?php echo e(__('DIAS')); ?></label>
                            
                            <div class="col-md-6">
                                <input id="dias" type="number" class="form-control" name="dias" value="<?php echo e($sancion->dias); ?>" required autocomplete="dias">
                                
                               
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="fecha" class="col-md-4 col-form-label text-md-right"><?php echo e(__('FECHA SANCION')); ?></label>

                            <div class="col-md-6">
                                <input id="fecha" type="date" class="form-control " name="fecha" value="<?php echo e($sancion->fecha); ?>" required autocomplete="fecha">

                                
                            </div>
                        </div>

                        <?php
                        if($_GET) 
                        {
                             $fecha = $_GET['fecha'];
                             $var_fecha = $_GET['dias'] +1;
                            $nueva_fecha = strtotime('+'. $var_fecha .'day', strtotime($fecha));
                            $nueva_fecha = date('Y-m-j', $nueva_fecha);
                        }
                        ?>
                        <div class="form-group row">
                            <label for="reincorporacion" class="col-md-4 col-form-label text-md-right"><?php echo e(__('FECHA REINCORPORACION')); ?>  </label>

                            <div class="col-md-6">
                                <input id="reincorporacion" type="date" class="form-control"  value="<?php if(!empty($nueva_fecha)): ?> <?php echo e($nueva_fecha); ?> <?php endif; ?>"  >
                                
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="motivo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('MOTIVO')); ?></label>
                            
                            <div class="col-md-6">
                                <input id="motivo" type="text" class="form-control" name="motivo" value="<?php echo e($sancion->motivo); ?>" required autocomplete="motivo">

                               
                            </div>
                        </div>
                        
                        <div class="form-group row">   
    
                            <label for="id_capataz" class="col-md-4 col-form-label text-md-right"><?php echo e(__('CAPATAZ')); ?></label>
                        
                            <div class="col-md-6">
                                <input id="fecha" type="text" class="form-control "  value="<?php if(!empty($empleado)): ?><?php echo e($empleado->capataz->nombre); ?> <?php endif; ?>">

                                
                            </div>                       
                            
                        </div>  
                        <div class="form-group row">   
    
                            <label for="id_cliente" class="col-md-4 col-form-label text-md-right"><?php echo e(__('EMPRESA')); ?></label>
                        
                                <div class="col-md-6">
                                <input id="fecha" type="text" class="form-control "  value="<?php if(!empty($empleado)): ?><?php echo e($empleado->empresa->razon_social); ?> <?php endif; ?>">

                                
                            </div>   
                        </div>  
                             
                        <div class="form-group row shadow-textarea green-border-focus">

                           <label for="observacion"><?php echo e(__('OBSERVACION')); ?></label>
                             <textarea class="form-control z-depth-1" id="observacion" rows="3" name="observacion"><?php echo e($sancion->observacion); ?></textarea>
                            </div>
                        </div>
    
                    
                        

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-2x fa-save mr-2" style="color:white"></i>
                                    <?php echo e(__('Grabar')); ?>

                                </button>
                                 <a class="fas fa-undo" role="button" href=  <?php echo e(url('/sancion')); ?> style='margin-left:5rem' style="cursor:pointer",name="Regresar" >  Regresar</a>
           
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </section>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alfredosarria/GSA/resources/views/modif_sancion.blade.php ENDPATH**/ ?>