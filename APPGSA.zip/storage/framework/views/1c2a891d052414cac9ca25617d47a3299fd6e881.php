<?php $__env->startSection('content'); ?>

<div class="container mt-5" id="contenido">
    <section>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-white text-center " style=" background-color:darkblue"><?php echo e(__('MODIFICACION EMPRESA')); ?></div>
                   <div class="mt-3">
                        <ul style='color:red' class="text-center">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li style='list-style:none'>
                                <?php echo e($error); ?>

                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
 
                    <div class="card-body">
                        <form method="POST" action="/modif_empresa/<?php echo e($empresa->id); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('PUT')); ?>


                            <div class="form-group row">
                                <label for="razon_social" class="col-md-4 col-form-label text-md-right"><?php echo e(__('RAZON SOCIAL')); ?></label>

                                <div class="col-md-6">
                                    <input id="razon_social" type="text" class="form-control" name="razon_social" value="<?php echo e($empresa->razon_social); ?>">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cuit" class="col-md-4 col-form-label text-md-right"><?php echo e(__('CUIT')); ?></label>

                                <div class="col-md-6">
                                    <input id="cuit" type="text" class="form-control" name="cuit" value="<?php echo e($empresa->cuit); ?>">

                                </div>
                            </div>

                             <div class="form-group row">
                                <label for="domicilio" class="col-md-4 col-form-label text-md-right"><?php echo e(__('DOMICILIO')); ?></label>

                                <div class="col-md-6">
                                    <input id="domicilio" type="text" class="form-control" name="domicilio" value="<?php echo e($empresa->domicilio); ?>">

                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary"><i class="fas fa-2x fa-save mr-2" style="color:white"></i>
                                        <?php echo e(__('Grabar')); ?>

                                    </button>
                                    <a class="fas fa-undo" role="button" href=<?php echo e(url('/abm_empresa')); ?> style='margin-left:5rem' style="cursor:pointer" name="Regresar" title="Volver al listado">Regresar</a>

                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alfredosarria/GSA/resources/views/modif_empresa.blade.php ENDPATH**/ ?>