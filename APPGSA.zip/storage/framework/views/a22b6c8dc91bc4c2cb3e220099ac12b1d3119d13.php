<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <style>
        h1 {
            text-align: center;
            text-transform: uppercase;
        }

        h2 {
            text-align: center;
            text-transform: uppercase;
        }

        .contenido {
            font-size: 20px;
        }

        #primero {
            background-color: #ccc;
        }

        #segundo {
            color: #44a359;
        }

        #tercero {
            text-decoration: line-through;
        }
    </style>
</head>

<body>
    <div alighn="center"> <img src="../public/img/gsa.png" alt="" style="width: 120px"></div>
    <h1></h1>
    <h2>PARTE DE COSECHA DE EL: <?php echo e($cosecha->fecha); ?></h2>
    <hr>
    <div class="contenido">
        <p id="primero">Cliente: <?php echo e($cosecha->cliente->nombre); ?> </p>
        <p id="segundo">Capataz: <?php echo e($cosecha->capataz->nombre); ?> </p>
        <p id="primero">Jornales: <?php echo e($cosecha->jornales); ?> </p>
        <p id="segundo">Cosecheros: <?php echo e($cosecha->cosecheros); ?> </p>
        <p id="primero">Bines: <?php echo e($cosecha->bines); ?> </p>
        <p id="segundo">Maletas: <?php echo e($cosecha->maletas); ?> </p>
        <p id="primero">Toneladas: <?php echo e($cosecha->toneladas); ?> </p>
        <p id="segundo">Promedio Kilos Bins: <?php echo e($cosecha->prom_kg_bin); ?></p>
        <p id="primero">Supervisor: <?php echo e($cosecha->supervisor); ?> </p>
    </div>
</body>

</html><?php /**PATH /Users/alfredosarria/GSA/resources/views/pdf_cosecha.blade.php ENDPATH**/ ?>