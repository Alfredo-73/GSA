<?php $__env->startSection('content'); ?>
<div class="row container-fluid col-md-10 col-lg-10" id="contenido">

    <div class="container-fluid mx-auto text-center">
        <h1 class="mx-auto mb-5 mt-5" style="font-family:Verdana, Geneva, Tahoma, sans-serif">DETALLE DE SANCIONES POR EMPLEADO</h1>
    </div>


    <div class="container-fluid">
        <nav class="navbar  navbar-dark indigo rounded mb-2">
            <span style="font-size:15px; font-family:Verdana, Geneva, Tahoma, sans-serif" class="text-white ml-5"><u>EMPLEADO</u>: <?php echo e($empleados->nombre); ?>, <?php echo e($empleados->apellido); ?> | <u>EMPRESA</u>: <?php echo e($empleados->empresa->razon_social); ?> | <u>CANTIDAD DE SANCIONES</u>: <?php echo e($cantidad_sancion); ?> | <u>CANTIDAD DE DIAS SANCIONADO</u>: <?php echo e($dias); ?></span>
            <a href="/empleadoSancionado/<?php echo e($empleados->id); ?>" title="Refrescar" name="Refrescar" style="color:white; font-family:Verdana, Geneva, Tahoma, sans-serif"><i class="fas fa-sync-alt ml-1" style="color:white"></i>Refrescar</a>
        </nav>
    </div>

    <div class="container-fluid">
        <div class="table-responsive-lg text-nowrap btn-table">
            <table class="table table-bordered table-hover">
                <thead class="thead-dark">
                    <thead class="text-center">
                        <tr height="65px" style="background-color:black; color:white">
                            <th class="text-center">LEGAJO</th>
                            <th class="text-center">NOMBRE</th>
                            <th class="text-center">APELLIDO</th>
                            <th class="text-center">DNI</th>
                            <th class="text-center">FECHA DE SANCION</th>
                            <th class="text-center">DIAS SANCIONADO</th>
                            <th class="text-center">FECHA REINCORPORACION</th>
                            <th class="text-center">CAPATAZ</th>
                            <th class="text-center">MOTIVO</th>
                            <th COLSPAN=2 class="text-center">ACCION</th>
                        </tr>
                        </<thead>
                    <tbody>
                        <?php $__currentLoopData = $sanciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sancion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"> <?php echo e($empleados->legajo); ?></td>
                            <td class="text-center"><?php echo e($empleados->nombre); ?> </td>
                            <td class="text-center"><?php echo e($empleados->apellido); ?> </td>
                            <td class="text-center"> <?php echo e($empleados->dni); ?></td>
                            <td class="text-center" name="fecha"> <?php echo e($sancion->fecha); ?></td>
                            <td class="text-center"> <?php echo e($sancion->dias); ?></td>
                            <td class="text-center"> <?php echo e($sancion->reincorporacion); ?></td>
                            <td class="text-center"> <?php echo e($sancion->capataz->nombre); ?></td>
                            <td class="text-center"> <?php echo e($sancion->motivo); ?></td>
                            <td class="text-center">
                                <form method="POST" action="<?php echo e(url('/borrar_sancion/'.$sancion->id)); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <a type="submit" onclick="return confirm('¿Desea eliminar el parte de sancion?')" id="borrar" class="btn peach-gradient btn-sm"><i class="fas fa-trash mr-2" style="color:white" role="button"></i>BORRAR
                                    </a>
                                </form>
                            </td>
                            <td class="text-center">
                                <form method="PUT" action="/modal_sancion/<?php echo e($sancion->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo e(method_field('PUT')); ?>

                                    <a type="button" class="btn blue-gradient btn-sm" href="/modal_sancion/<?php echo e($sancion->id); ?>" data-toggle="modal" data-target="#modal_sancion<?php echo e($sancion->id); ?>" form method="POST" action="/modalsancion/<?php echo e($sancion->id); ?>" role="button"><i class="fas fa-eye mr-1" style="color:white"></i>VER</a>
                                    <?php echo csrf_field(); ?>
                                    <?php echo e(method_field('PUT')); ?>

                                    <?php echo $__env->make('modal_sancion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
            </table>

            <H5 style="color:green">CANTIDAD DE SANCIONES: <strong><?php echo e($cantidad_sancion); ?></strong></H5>
            <H5 style="color:red">CANTIDAD DE DIAS SANCIONADO: <strong><?php echo e($dias); ?></strong></H5>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alfredosarria/GSA/resources/views/sancionPorEmpleado.blade.php ENDPATH**/ ?>