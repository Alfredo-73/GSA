<?php $__env->startSection('scripts'); ?>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php $__env->stopSection(); ?>
<script src="../js/borrar.js"></script>
<link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>">

<?php $__env->startSection('content'); ?>
<div class="row container-fluid col-md-10 col-lg-10" id="contenido">

    <div class="container-fluid mx-auto text-center">
        <h1 class="mx-auto mt-5 mb-5" style="font-family:Verdana, Geneva, Tahoma, sans-serif">PARTE DIARIO DE COSECHA</h1>
    </div>


    <div class="container-fluid text-nowrap mb-5">
        <div class="container-fluid">
            <nav class="navbar navbar-expand-xl navbar-dark indigo">
                <span style="font-size:15px; font-family:Verdana, Geneva, Tahoma, sans-serif" class="text-white ml-5">INGRESE RANGO DE FECHA Y/O CAPATAZ:</span>
                <form class="form-inline">
                    <input class="md-form mr-2 text-center rounded" type="date" placeholder="Desde" aria-label="Search" name="fechadesde" role="button">
                    <input class="md-form mr-2 text-center rounded" type="date" placeholder="Hasta" aria-label="Search" name="fechahasta" role="button">
                    <select class="selectpicker show-menu-arrow" name="buscacapataz" value="">
                        <option>Capataz</option>
                        <?php $__currentLoopData = $capataz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($capat->id); ?>"><?php echo e($capat->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <button class="btn blue-gradient btn-rounded btn-sm my-0"><i class="fas fa-search fa-2x mr-2" style="color:white" name="buscar"></i>Buscar</button>

                    <a href="<?php echo e(url('/cosecha')); ?>" title="Refrescar" name="Refrescar" style="color:white; font-family:Verdana, Geneva, Tahoma, sans-serif"><i class="fas fa-sync-alt ml-1" style="color:white"></i>Refrescar</a>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('agregar_cosecha')): ?>
                    <div>
                        <a id="agregar" class="btn primary-color-dark rounded" href="<?php echo e(url('/nueva_cosecha')); ?>" role="button" style="color:white"><i class="fas fa-2x fa-plus mr-2" style="color:white"></i>NUEVO </a>
                    </div>
                    <?php endif; ?>

                    <?php if(($varfechadesde || $varfechahasta) || ($varbuscacapataz) && ($varbuscacapataz !='Capataz')): ?><a role="button" class="btn-sm btn-deep-orange ml-3" href="verreportecosechaPDF/<?php echo e($varfechadesde); ?>/<?php echo e($varfechahasta); ?>/<?php echo e($varbuscacapataz); ?>"><i class="fas fa-print mr-2" style="color:white"></i>Imprimir</a> <?php endif; ?>
                    <?php if((empty($varfechadesde) && empty($varfechahasta) || ($varbuscacapataz=='Capataz')) && (($varbuscacapataz =='Capataz') && ($varfechadesde ==null) && ($varfechahasta==null))): ?><a role="button" class="btn-sm btn-deep-orange ml-3" href="verreportecosechaPDF"><i class="fas fa-print mr-2" style="color:white"></i>Imprimir</a> <?php endif; ?>
                </form>
            </nav>
        </div>
    </div>

    <div class="row container-fluid">
        <?php echo e($cosechas->appends($_GET)->links()); ?>

    </div>
    <!--Table-->
    <div class="container-fluid">
        <div class="table-responsive-lg text-nowrap btn-table">
            <table class="table table-bordered table-hover">
                <thead class="thead-dark">
                    <thead class="text-center">
                        <tr height="65px" style="background-color:black; color:white">
                            <th class="text-center text-truncate">FECHA</th>
                            <th class="text-center text-truncate">CLIENTE</th>
                            <th class="text-center text-truncate">CAPATAZ</th>
                            <th class="text-center text-truncate">JORNALES</th>
                            <th class="text-center text-truncate">COSECHEROS</th>
                            <th class="text-center text-truncate">BINES</th>
                            <th class="text-center text-truncate">MALETAS</th>
                            <th class="text-center text-truncate">TONELADAS</th>
                            <th class="text-center text-truncate">PROM.KG/BIN</th>
                            <th class="text-center text-truncate">SUPERVISOR</th>
                            <th COLSPAN=2 class="text-center">ACCIONES DISPONIBLES</th>
                        </tr>
                    </thead>
                    <!--Table head-->

                    <!--Table body-->
                <tbody>
                    <?php $__currentLoopData = $cosechas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cosecha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center text-truncate" name="fecha"> <?php echo e($cosecha->fecha); ?></td>
                        <td class="text-center text-truncate"> <?php echo e($cosecha->cliente->nombre); ?></td>
                        <td class="text-center text-truncate"> <?php echo e($cosecha->capataz->nombre); ?></td>
                        <td class="text-center text-truncate"> <?php echo e($cosecha->jornales); ?></td>
                        <td class="text-center text-truncate"> <?php echo e($cosecha->cosecheros); ?></td>
                        <td class="text-center text-truncate"> <?php echo e($cosecha->bines); ?></td>
                        <td class="text-center text-truncate"> <?php echo e($cosecha->maletas); ?></td>
                        <td class="text-center text-truncate"> <?php echo e($cosecha->toneladas); ?></td>
                        <td class="text-center text-truncate"> <?php echo e($cosecha->prom_kg_bin); ?></td>
                        <td class="text-center text-truncate"> <?php echo e($cosecha->supervisor); ?></td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar_cosecha')): ?>
                        <td class="text-center">
                            <button type="" onclick="return borrar(this)" value="<?php echo e($cosecha->id); ?>" id="borrar" name="borrar" class="btn peach-gradient mb-1 btn-sm m-0 text-center text-truncate"><i class="fas fa-trash mr-2" style="color:white" role="button"></i>BORRAR</button>
                        </td>
                        <?php endif; ?>
                        <td class="text-center">
                            <form method="PUT" action="/modalcosecha/<?php echo e($cosecha->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('PUT')); ?>

                                <a type="button" class="btn blue-gradient mb-1 btn-sm m-0 text-center text-truncate" href="/modalcosecha/<?php echo e($cosecha->id); ?>" data-toggle="modal" data-target="#modalcosecha<?php echo e($cosecha->id); ?>" form method="POST" action="/modalcosecha/<?php echo e($cosecha->id); ?>" role="button" style="text-align:justify"><i class="fas fa-eye mr-1" style="color:white"></i>VER</a>
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('PUT')); ?>

                                <?php echo $__env->make('modalcosecha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <!--Table body-->
            </table>
            <!--<?php echo e($cosechas->render()); ?>-->
        </div>
        <?php echo e($cosechas->appends($_GET)->links()); ?>

        <!--Table-->
    </div>
</div>
<?php echo e($cosechas->appends($_GET)->links()); ?>

<!--Table-->

<!--Section: Content-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alfredosarria/GSA/resources/views//cosecha.blade.php ENDPATH**/ ?>