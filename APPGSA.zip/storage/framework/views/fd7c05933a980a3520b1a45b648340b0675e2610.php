<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
<style>
	h1{
		text-align: center;
		text-transform: uppercase;
	}
    h2{
		text-align: center;
		text-transform: uppercase;
	}
	.contenido{
		font-size: 20px;
	}
	#primero{
		background-color: #ccc;
	}
	#segundo{
		color:#44a359;
	}
	#tercero{
		text-decoration:line-through;
	}
</style>
</head>
<body>
    <div alighn="center"> <img src="../public/img/gsa.png" alt="" style="width: 120px"></div>
  
    <h1></h1>
    <h2>INFORME control quincenal  <?php echo e($control->quincena->nombre); ?></h2>
	<hr>
	<div class="contenido">
         <?php $disponible = $control->importe-($control->retencion + $control->gasto_bancario); ?>
         <?php $totalPago = $control->pago_personal + $control->pago_transporte; ?>
		<p id="primero">Nombre cliente:<?php echo e($control->cliente->nombre); ?></p>
        <p id="segundo">Numero Factura:<?php echo e($control->num_factura); ?>   </p>
        <p id="primero">Importe: <?php echo e($control->importe); ?>         </p>
        <p id="segundo">Retencion:<?php echo e($control->retencion); ?>      </p>
        <p id="primero">Monto cobrado:<?php echo e($control->monto_cobrado); ?>  </p>
        <p id="segundo">Gasto Bancario:<?php echo e($control->gasto_bancario); ?> </p>
        <p id="primero">Libre Disponibilidad:<?php echo e($control->libre_dispon); ?> </p>
        <p id="segundo">Pago Personal:<?php echo e($control->pago_personal); ?>   </p>
        <p id="primero">Pago Transporte:<?php echo e($control->pago_transporte); ?></p>
        <p id="segundo">Neto Quincena: $ <?php echo e($disponible - $totalPago); ?>      </p> 
        <p id="primero">Costo Tonelada: <?php echo e(($disponible - $totalPago)/$control->toneladas); ?></p>
		<p id="segundo">Toneladas: <?php echo e($control->toneladas); ?>       </p> 
		<p id="segundo">Observacion: <?php echo e($control->observacion); ?></p>
		
    </div>
    
	
</body>
</html><?php /**PATH /Users/alfredosarria/GSA/resources/views/pdf1.blade.php ENDPATH**/ ?>