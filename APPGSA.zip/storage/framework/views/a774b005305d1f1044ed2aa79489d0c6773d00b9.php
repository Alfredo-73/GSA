<?php $__env->startSection('scripts'); ?>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php $__env->stopSection(); ?>
<script src="../js/borrar_control_quincenal.js"></script>
<link rel="stylesheet" href="<?php echo e(asset('css/estilos_control.css')); ?>">

<?php $__env->startSection('content'); ?>
<div class="row container-fluid col-md-10 col-lg-10" id="contenido">

    <div class="container-fluid mx-auto text-center" id="titulo">
        <h1 class="mx-auto mt-5 mb-5" style="font-family:Verdana, Geneva, Tahoma, sans-serif">CONTROL QUINCENAL DE FACTURACION Y PAGO</h1>
    </div>

    <div class="container-fluid text-nowrap mb-5">
        <div class="container-fluid">
            <nav class="navbar navbar-expand-lg navbar-dark indigo mb-2 rounded">
                <!-- <div class="row">
                    <p class="text-wrap" style="color:white; position:absolute; z-index:2; margin-left:8rem; margin-top:-2.5rem">INGRESE ClIENTE Y/O QUINCENA</span>
                </div>-->
                <a class="navbar-brand ml-3" href="#">Buscador:</a>


                <form class="form-inline md-form mr-auto mb-4 float-right" action="">
                    <select name="buscarporcliente" class="selectpicker show-menu-arrow">
                        <option>Cliente</option>
                        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cliente->id); ?>" <?php if(old('buscarporcliente')): ?>selected <?php endif; ?>><?php echo e($cliente->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                    <select name="buscarporquincena" class="selectpicker show-menu-arrow ml-1">
                        <option>Quincena</option>
                        <?php $__currentLoopData = $quincenas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quincena): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($quincena->id); ?>" <?php if(old('buscarporquincena')): ?>selected <?php endif; ?>><?php echo e($quincena->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <button class="btn blue-gradient btn-rounded btn-sm my-0" type="submit"><i class="fas fa-search fa-2x mr-2" style="color:white"></i>Buscar</button>
                    <a href="<?php echo e(url('/control_quincenal')); ?>" title="Refrescar" name="Refrescar" style="color:white; font-family:Verdana, Geneva, Tahoma, sans-serif"><i class="fas fa-sync-alt ml-1" style="color:white"></i>Refrescar</a>
                    <?php if(($varcliente||$varquincena)&&($varcliente != 'Cliente' || $varquincena != 'Quincena' ) ): ?> <a class="btn btn-deep-orange" href="/imprimir/<?php echo e($varcliente); ?>/<?php echo e($varquincena); ?>"><i class="fas fa-print fa-2x mr-2" style="color:white"></i>Imprimir Busqueda</a> <?php endif; ?>
                    <?php if(empty($varcliente)|| empty($varquincena)||($varcliente=='Cliente') && ($varquincena=='Quincena') ): ?> <a class="btn btn-deep-orange btn-rounded btn-sm my-0" href="/imprimir"><i class="fas fa-print fa-2x mr-2" style="color:white"></i>Imprimir reporte</a> <?php endif; ?>
                    <div>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('agregar_control')): ?>
                        <a id="agregar" class="btn blue-gradient btn-rounded btn-sm my-0" href="<?php echo e(url('/nuevo_control')); ?>" role="button" style="color:white"><i class="fas fa-2x fa-plus mr-2" style="color:white"></i>NUEVO </a>
                        <?php endif; ?>
                    </div>
                </form>
            </nav>
        </div>
    </div>

    <div class="row container-fluid">
        <?php echo e($controles->render()); ?>

    </div>
    <!--Table-->
    <div class="container-fluid">
        <div class="table-responsive-lg text-nowrap btn-table">
            <table class="table table-bordered table-hover">
                <thead class="thead-dark">
                    <thead class="text-center">
                        <tr height="65px" style="background-color:black; color:white">
                            <th class="text-center text-truncate">CLIENTE</th>
                            <th class="text-center text-truncate">QUINCENA</th>
                            <th class="text-center text-truncate">Nº FACTURA</th>
                            <th class="text-center text-truncate">IMPORTE</th>
                            <th class="text-center text-truncate">MONTO COBRADO</th>
                            <th class="text-center text-truncate">GASTOS BANCARIOS</th>
                            <th class="text-center text-truncate">DISPONIBLE</th>
                            <th class="text-center text-truncate">TOTAL PAGO</th>
                            <th class="text-center text-truncate">NETO QCNA</th>
                            <th class="text-center text-truncate">COSTO Tn</th>
                            <th colspan=2 class="text-center">ACCION</th>
                        </tr>
                    </thead>
                    <!--Table head-->

                    <!--Table body-->
                <tbody>

                    <?php $__currentLoopData = $controles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $control): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php $disponible = $control->importe - ($control->retencion + $control->gasto_bancario); ?>
                        <?php $totalPago = $control->pago_personal + $control->pago_transporte; ?>

                        <td class="text-center text-truncate"> <?php echo e($control->cliente->nombre); ?></td>
                        <td class="text-center text-truncate"> <?php echo e($control->quincena->nombre); ?></td>
                        <td class="text-center text-truncate"> <?php echo e($control->num_factura); ?></td>
                        <td class="text-center text-truncate">$ <?php echo e($control->importe); ?></td>
                        <td class="text-center text-truncate">$ <?php echo e($control->monto_cobrado); ?></td>
                        <td class="text-center text-truncate">$ <?php echo e($control->gasto_bancario); ?></td>
                        <td class="text-center text-truncate">$ <?php echo e($disponible); ?></td>
                        <td class="text-center text-truncate">$ <?php echo e($totalPago); ?></td>
                        <td class="text-center text-truncate">$ <?php echo e($disponible - $totalPago); ?></td>
                        <td class="text-center text-truncate">$ <?php echo e(round((($disponible - $totalPago)/$control->toneladas),2)); ?></td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar_control')): ?>
                        <td class="text-center">
                            <button type="" onclick="return borrar(this)" value="<?php echo e($control->id); ?>" id="borrar" name="borrar" class="btn peach-gradient mb-1 btn-sm m-0 text-center text-truncate"><i class="fas fa-trash mr-2" style="color:white" role="button"></i>BORRAR</button>

                        </td>
                        <?php endif; ?>
                        <td>
                            <form method="PUT" action="/modal_control/<?php echo e($control->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('PUT')); ?>

                                <a type="button" href="/modal_control/<?php echo e($control->id); ?>" class="btn blue-gradient mb-1 btn-sm m-0 text-center text-truncate" data-toggle="modal" data-target="#modal_control<?php echo e($control->id); ?>" form method="POST" action="/modal_control/<?php echo e($control->id); ?>" role="button" style="text-align:justify"><i class="fas fa-eye mr-1" style="color:white"></i>VER</a>
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('PUT')); ?>

                                <?php echo $__env->make('modal_control', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo e($controles->appends($_GET)->links()); ?>


    </div>
</div>

<!--Section: Content-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alfredosarria/GSA/resources/views/control_quincenal.blade.php ENDPATH**/ ?>