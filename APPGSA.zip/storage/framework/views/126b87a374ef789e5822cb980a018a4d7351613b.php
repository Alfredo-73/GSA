<?php $__env->startSection('content'); ?>
<div class="row container-fluid col-10 mt-5" id="contenido">

    <div class="col-8 mx-auto mt-1">
        <div class="card">
            <div class="card-header text-white text-center" style="background-color:darkblue; font-size:25px">MODIFICACION DE ROL</div>
            <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> Tenemos un problema con su entrada.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>


            <?php echo Form::model($role, ['method' => 'PATCH','route' => ['roles.update', $role->id]]); ?>

            <!--<div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <strong>NOMBRE:</strong>
                            <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')); ?>

                        </div>
                    </div>-->

            <div class="input-group col-10 mt-4 mb-3 d-flex justify-content-center align-items-center container">
                <div class="input-group-prepend">
                    <span class="input-group-text"><strong>NOMBRE DEL ROL</strong></span>
                </div>
                <input type="text" name="name" aria-label="name" class="form-control" value="<?php echo e($role->name); ?>">
            </div>

            <!--<div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>PERMISOS ASIGNADOS:</strong>
                        <br />
                        <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label><?php echo e(Form::checkbox('permission[]', $value->id, in_array($value->id, $rolePermissions) ? true : false, array('class' => 'name'))); ?>

                            <?php echo e($value->name); ?></label>
                        <br />
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>-->

            <div class="card ml-3" style="width:95%">
                <div class="row justify-content-center mb-4" style="font-size:18px">
                    <strong>PERMISOS DISPONIBLES</strong>
                </div>

                <div class="row justify">
                    <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-3 mr-1 mb-1 justify-content-center align-items-center container">
                        <label><?php echo e(Form::checkbox('permission[]', $value->id, in_array($value->id, $rolePermissions) ? true : false, array('class' => 'name'))); ?>

                            <?php echo e($value->name); ?></label>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12 text-center mt-3 mb-2">
                <button type="submit" class="btn btn-success">GRABAR</button>
                <a class="btn btn-primary" href="<?php echo e(route('roles.index')); ?>"> REGRESAR</a>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alfredosarria/GSA/resources/views/roles/edit.blade.php ENDPATH**/ ?>