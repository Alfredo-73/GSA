<?php $__env->startSection('content'); ?>
<div class="row container-fluid col-10 mt-5" id="contenido">
    <div class="col-8 mx-auto mt-5">
        <div class="card">
            <div class="card-header text-white text-center" style="background-color:darkblue; font-size:25px">MODIFICACION DE PERMISO</div>

            <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> Tenemos un problema con su entrada.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>


            <?php echo Form::model($permiso, ['method' => 'PATCH','route' => ['permisos.update', $permiso->id]]); ?>

            <div class="row">
                <div class="input-group col-10 mt-3 d-flex justify-content-center align-items-center container">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><strong>NOMBRE DEL PERMISO</strong></span>
                    </div>
                    <input type="text" name="name" aria-label="name" class="form-control" value="<?php echo e($permiso->name); ?>">
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <button type="submit" class="btn btn-success">GRABAR</button>
                    <a class="btn btn-primary" href="<?php echo e(route('permisos.index')); ?>"> REGRESAR</a>
                </div>
            </div>
        </div>

        <?php echo Form::close(); ?>



        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alfredosarria/GSA/resources/views/permisos/edit.blade.php ENDPATH**/ ?>