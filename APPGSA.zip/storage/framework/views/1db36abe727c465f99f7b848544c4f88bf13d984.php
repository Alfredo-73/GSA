<?php $__env->startSection('content'); ?>

<div class="container mt-5" id="contenido">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header text-white text-center" style="background-color:darkblue"><?php echo e(__('PARTE DIARIO COSECHA')); ?></div>
                   <div class="mt-3">
                        <ul style='color:red' class="text-center">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li style='list-style:none'>
                                <?php echo e($error); ?>

                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
 
                <div class="card-body">
                    <form method="POST" action="<?php echo e(url('/nueva_cosecha')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="fecha" class="col-md-4 col-form-label text-md-right"><?php echo e(__('FECHA')); ?></label>

                            <div class="col-md-6">
                                <input id="fecha" type="date" class="form-control" name="fecha" value="<?php echo e(old('fecha')); ?>" >

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="id_cliente" class="col-md-4 col-form-label text-md-right"><?php echo e(__('CLIENTE')); ?></label>

                            <select class="selectpicker show-menu-arrow" name="id_cliente" data-style="btn-success" data-width="auto">
                                <option selected>Elegir Cliente</option>
                                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nombre); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                        </div>
                        <div class="form-group row">
                            <label for="id_capataz" class="col-md-4 col-form-label text-md-right"><?php echo e(__('CAPATAZ')); ?></label>

                            <select class="selectpicker show-menu-arrow" name="id_capataz" data-style="btn-success" data-width="auto">
                                <option selected>Elegir Capataz</option>
                                <?php $__currentLoopData = $capataz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($capat->id); ?>"><?php echo e($capat->nombre); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                        </div>
                        <!--
                        <div class="form-group row">
                            <label for="capataz" class="col-md-4 col-form-label text-md-right"><?php echo e(__('CAPATAZ')); ?></label>

                            <div class="col-md-6">
                                <input id="capataz" type="text" class="form-control <?php $__errorArgs = ['capataz'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="capataz"  value="<?php echo e(old('capataz')); ?>" required autocomplete="capataz">

                                <?php $__errorArgs = ['capataz'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div> -->

                        <div class="form-group row">
                            <label for="jornales" class="col-md-4 col-form-label text-md-right"><?php echo e(__('JORNALES')); ?></label>

                            <div class="col-md-6">
                                <input id="jornales" type="text" class="form-control" name="jornales" value="<?php echo e(old('jornales')); ?>" >

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="cosecheros" class="col-md-4 col-form-label text-md-right"><?php echo e(__('COSECHEROS')); ?></label>

                            <div class="col-md-6">
                                <input id="cosecheros" type="text" class="form-control <?php $__errorArgs = ['cosecheros'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cosecheros" value="<?php echo e(old('cosecheros')); ?>" >

                            
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="bines" class="col-md-4 col-form-label text-md-right"><?php echo e(__('BINES')); ?></label>

                            <div class="col-md-6">
                                <input id="bines" type="text" class="form-control <?php $__errorArgs = ['bines'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="bines" value="<?php echo e(old('bines')); ?>" >

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="maletas" class="col-md-4 col-form-label text-md-right"><?php echo e(__('MALETAS')); ?></label>

                            <div class="col-md-6">
                                <input id="maletas" type="text" class="form-control " name="maletas" value="<?php echo e(old('maletas')); ?>" >

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="toneladas" class="col-md-4 col-form-label text-md-right"><?php echo e(__('TONELADAS')); ?></label>

                            <div class="col-md-6">
                                <input id="toneladas" type="text" class="form-control" name="toneladas" value="<?php echo e(old('toneladas')); ?>">

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="prom_kg_bin" class="col-md-4 col-form-label text-md-right"><?php echo e(__('PROMEDIO KG/BIN')); ?></label>

                            <div class="col-md-6">
                                <input id="prom_kg_bin" type="text" class="form-control" name="prom_kg_bin" value="<?php echo e(old('prom_kg_bin')); ?>" >
                            
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="supervisor" class="col-md-4 col-form-label text-md-right"><?php echo e(__('SUPERVISOR')); ?></label>

                            <div class="col-md-6">
                                <input id="supervisor" type="text" class="form-control " name="supervisor" value="<?php echo e(old('supervisor')); ?>">

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="transportista" class="col-md-4 col-form-label text-md-right"><?php echo e(__('TRANSPORTISTA')); ?></label>

                            <div class="col-md-6">
                                <input id="transportista" type="text" class="form-control " name="transportista" value="<?php echo e(old('transportista')); ?>">

                            </div>
                        </div>





                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-2x fa-save mr-2" style="color:white"></i>
                                    <?php echo e(__('Grabar')); ?>

                                </button>
                                <a class="fas fa-undo" role="button" href=<?php echo e(url('/cosecha')); ?> style='margin-left:5rem' style="cursor:pointer" ,name="Regresar"> Regresar</a>

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/alfredosarria/GSA/resources/views/nueva_cosecha.blade.php ENDPATH**/ ?>