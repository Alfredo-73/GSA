<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ver_imprimirController extends Controller
{
    //
    public function ver_imprimir()
    {
        return view('ver_imprimir');
    }
}
